This project was created as a proof of concept to show that without proper validation, XSS will happen!
